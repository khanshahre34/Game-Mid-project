using UnityEngine;

public class HealthSystem : MonoBehaviour
{
    public int maxHealth = 100;
    public int currentHealth;

    private void Start()
    {
        currentHealth = maxHealth;
        RefreshUI();
    }

    public void TakeDamage(int damage)
    {
        currentHealth = Mathf.Max(0, currentHealth - damage);
        RefreshUI();

        if (currentHealth <= 0)
        {
            Debug.Log("Player defeated");
        }
    }

    public void Heal(int amount)
    {
        currentHealth = Mathf.Min(maxHealth, currentHealth + amount);
        RefreshUI();
    }

    private void RefreshUI()
    {
        if (GameTimer.Instance != null)
        {
            GameTimer.Instance.UpdateHealth(currentHealth, maxHealth);
        }
    }
}
