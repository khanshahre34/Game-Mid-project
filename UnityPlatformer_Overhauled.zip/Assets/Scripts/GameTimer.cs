using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameTimer : MonoBehaviour
{
    public static GameTimer Instance { get; private set; }

    [Header("Level")]
    public float timeLeft = 180f;

    private TMP_Text scoreText;
    private TMP_Text timerText;
    private TMP_Text coinsText;
    private TMP_Text healthText;

    private AudioSource musicSource;
    private AudioSource sfxSource;
    private AudioClip jumpClip;
    private AudioClip coinClip;
    private AudioClip finishClip;

    private Renderer finishRenderer;
    private Material finishMaterial;

    private int score;
    private int coinsCollected;
    private int totalCoins;
    private bool gameEnded;

    public bool GameEnded => gameEnded;

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        FindUI();
        SetupAudio();
        SetupFinishLine();

        Coin[] coins = FindObjectsByType<Coin>(FindObjectsSortMode.None);
        totalCoins = coins.Length;

        UpdateScoreUI();
        UpdateCoinUI();
        UpdateTimerUI();

        HealthSystem playerHealth = FindFirstObjectByType<HealthSystem>();
        if (playerHealth != null)
        {
            UpdateHealth(playerHealth.currentHealth, playerHealth.maxHealth);
        }
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.R) && gameEnded)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            return;
        }

        if (!gameEnded)
        {
            timeLeft = Mathf.Max(0f, timeLeft - Time.deltaTime);
            UpdateTimerUI();
            AnimateFinishLine();

            if (timeLeft <= 0f)
            {
                EndGame(false);
            }
        }
    }

    private void FindUI()
    {
        scoreText = FindText("ScoreText");
        timerText = FindText("TimerText");
        coinsText = FindText("CoinsText");
        healthText = FindText("HealthText");

        StyleHudText(scoreText);
        StyleHudText(timerText);
        StyleHudText(coinsText);
        StyleHudText(healthText);
    }

    private TMP_Text FindText(string objectName)
    {
        GameObject obj = GameObject.Find(objectName);
        return obj != null ? obj.GetComponent<TMP_Text>() : null;
    }

    private void StyleHudText(TMP_Text text)
    {
        if (text == null) return;

        text.fontStyle = FontStyles.Bold;
        text.outlineWidth = 0.18f;
        text.outlineColor = new Color32(0, 0, 0, 190);
        text.raycastTarget = false;
    }

    private void SetupAudio()
    {
        musicSource = gameObject.AddComponent<AudioSource>();
        sfxSource = gameObject.AddComponent<AudioSource>();

        musicSource.playOnAwake = false;
        musicSource.loop = true;
        musicSource.volume = 0.24f;
        musicSource.spatialBlend = 0f;

        sfxSource.playOnAwake = false;
        sfxSource.volume = 0.85f;
        sfxSource.spatialBlend = 0f;

        AudioClip backgroundMusic = Resources.Load<AudioClip>("Audio/BackgroundMusic");
        jumpClip = Resources.Load<AudioClip>("Audio/Jump");
        coinClip = Resources.Load<AudioClip>("Audio/Coin");
        finishClip = Resources.Load<AudioClip>("Audio/Finish");

        if (backgroundMusic != null)
        {
            musicSource.clip = backgroundMusic;
            musicSource.Play();
        }
    }

    private void SetupFinishLine()
    {
        GameObject finish = GameObject.Find("FinishLine");
        if (finish == null) return;

        BoxCollider finishCollider = finish.GetComponent<BoxCollider>();
        if (finishCollider != null)
        {
            finishCollider.isTrigger = true;
        }

        finishRenderer = finish.GetComponent<Renderer>();
        if (finishRenderer == null) return;

        finishMaterial = finishRenderer.material;
        finishMaterial.EnableKeyword("_EMISSION");
        finishMaterial.SetColor("_BaseColor", new Color(0.12f, 0.95f, 0.35f, 1f));
        finishMaterial.SetColor("_Color", new Color(0.12f, 0.95f, 0.35f, 1f));
    }

    private void AnimateFinishLine()
    {
        if (finishMaterial == null) return;

        float pulse = 1.4f + (Mathf.Sin(Time.time * 4f) + 1f) * 0.8f;
        finishMaterial.SetColor("_EmissionColor", new Color(0.05f, 0.8f, 0.18f, 1f) * pulse);
    }

    public void CollectCoin(int value)
    {
        if (gameEnded) return;

        coinsCollected++;
        score += value;

        UpdateCoinUI();
        UpdateScoreUI();
        PlayOneShot(coinClip, 0.95f);
    }

    public void PlayJumpSound()
    {
        if (gameEnded) return;
        PlayOneShot(jumpClip, 0.72f);
    }

    public void UpdateHealth(int current, int maximum)
    {
        if (healthText != null)
        {
            healthText.text = $"Health: {current}/{maximum}";
        }
    }

    public void WinGame()
    {
        if (gameEnded) return;

        int timeBonus = Mathf.CeilToInt(timeLeft) * 2;
        score += timeBonus;
        gameEnded = true;

        PlayOneShot(finishClip, 1f);
        if (musicSource != null)
        {
            musicSource.volume = 0.10f;
        }

        StopPlayerControl();

        if (scoreText != null)
        {
            RectTransform rect = scoreText.rectTransform;
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = new Vector2(760f, 360f);

            scoreText.alignment = TextAlignmentOptions.Center;
            scoreText.fontSize = 58f;
            scoreText.text =
                $"YOU WIN!\n\nScore: {score}\nCoins: {coinsCollected}/{totalCoins}\nTime Bonus: +{timeBonus}\n\nPress R to Play Again";
        }
    }

    private void EndGame(bool won)
    {
        if (won)
        {
            WinGame();
            return;
        }

        gameEnded = true;
        StopPlayerControl();

        if (musicSource != null)
        {
            musicSource.volume = 0.08f;
        }

        if (scoreText != null)
        {
            RectTransform rect = scoreText.rectTransform;
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = new Vector2(700f, 260f);

            scoreText.alignment = TextAlignmentOptions.Center;
            scoreText.fontSize = 56f;
            scoreText.text = $"TIME'S UP!\n\nScore: {score}\nCoins: {coinsCollected}/{totalCoins}\n\nPress R to Try Again";
        }
    }

    private void StopPlayerControl()
    {
        PlayerMovement movement = FindFirstObjectByType<PlayerMovement>();
        if (movement != null)
        {
            Rigidbody playerBody = movement.GetComponent<Rigidbody>();
            if (playerBody != null)
            {
                playerBody.linearVelocity = Vector3.zero;
                playerBody.angularVelocity = Vector3.zero;
            }

            movement.enabled = false;
        }

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    private void UpdateScoreUI()
    {
        if (scoreText != null)
        {
            scoreText.text = $"Score: {score}";
        }
    }

    private void UpdateCoinUI()
    {
        if (coinsText != null)
        {
            coinsText.text = $"Coins: {coinsCollected}/{totalCoins}";
        }
    }

    private void UpdateTimerUI()
    {
        if (timerText == null) return;

        int seconds = Mathf.CeilToInt(timeLeft);
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        timerText.text = $"Time: {minutes:00}:{remainingSeconds:00}";
    }

    private void PlayOneShot(AudioClip clip, float volume)
    {
        if (clip != null && sfxSource != null)
        {
            sfxSource.PlayOneShot(clip, volume);
        }
    }
}
