using UnityEngine;

public class ObstacleLineMovement : MonoBehaviour
{
    public float moveDistance = 1.5f;
    public float moveSpeed = 1.5f;
    public float startDelay = 0f;

    private Vector3 startPosition;

    void Start()
    {
        startPosition = transform.position;
    }

    void Update()
    {
        float movement =
            Mathf.Sin((Time.time + startDelay) * moveSpeed)
            * moveDistance;

        transform.position = new Vector3(
            startPosition.x + movement,
            startPosition.y,
            startPosition.z
        );
    }
}