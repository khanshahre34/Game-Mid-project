using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform player;
    public Vector3 offset = new Vector3(0f, 6f, -8f);
    public float followSmoothness = 12f;
    public float lookHeight = 1f;

    private float pitch;

    public void SetPitch(float newPitch)
    {
        pitch = newPitch * 0.35f;
    }

    private void LateUpdate()
    {
        if (player == null) return;

        Quaternion orbitRotation = Quaternion.Euler(
            pitch,
            player.eulerAngles.y,
            0f
        );

        Vector3 targetPosition = player.position + orbitRotation * offset;
        float blend = 1f - Mathf.Exp(-followSmoothness * Time.deltaTime);

        transform.position = Vector3.Lerp(
            transform.position,
            targetPosition,
            blend
        );

        Vector3 lookTarget = player.position + Vector3.up * lookHeight;
        Quaternion targetRotation = Quaternion.LookRotation(
            lookTarget - transform.position
        );

        transform.rotation = Quaternion.Slerp(
            transform.rotation,
            targetRotation,
            blend
        );
    }
}
