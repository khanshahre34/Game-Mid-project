using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class PlayerMovement : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float moveSpeed = 6f;
    [SerializeField] private float acceleration = 24f;
    [SerializeField] private float airControl = 0.7f;

    [Header("Jump")]
    [SerializeField] private float jumpForce = 7f;
    [SerializeField] private float coyoteTime = 0.12f;
    [SerializeField] private float jumpBufferTime = 0.12f;

    [Header("Mouse Look")]
    [SerializeField] private Transform playerCamera;
    [SerializeField] private float mouseSensitivity = 200f;
    [SerializeField] private float maximumLookAngle = 80f;

    private Rigidbody rb;
    private float horizontalInput;
    private float verticalInput;
    private float playerYaw;
    private float cameraPitch;
    private float coyoteCounter;
    private float jumpBufferCounter;
    private bool isGrounded;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();

        rb.constraints =
            RigidbodyConstraints.FreezeRotationX |
            RigidbodyConstraints.FreezeRotationZ;

        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.Continuous;

        if (playerCamera == null && Camera.main != null)
        {
            playerCamera = Camera.main.transform;
        }

        playerYaw = transform.eulerAngles.y;

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    private void Update()
    {
        horizontalInput = Input.GetAxisRaw("Horizontal");
        verticalInput = Input.GetAxisRaw("Vertical");

        HandleMouseLook();

        if (isGrounded)
        {
            coyoteCounter = coyoteTime;
        }
        else
        {
            coyoteCounter -= Time.deltaTime;
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            jumpBufferCounter = jumpBufferTime;
        }
        else
        {
            jumpBufferCounter -= Time.deltaTime;
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }

        if (Input.GetMouseButtonDown(0))
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }
    }

    private void FixedUpdate()
    {
        MovePlayer();
        TryJump();
    }

    private void HandleMouseLook()
    {
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

        playerYaw += mouseX;
        cameraPitch -= mouseY;
        cameraPitch = Mathf.Clamp(cameraPitch, -maximumLookAngle, maximumLookAngle);

        if (playerCamera != null)
        {
            CameraFollow cameraFollow = playerCamera.GetComponent<CameraFollow>();

            if (cameraFollow != null)
            {
                cameraFollow.SetPitch(cameraPitch);
            }
            else
            {
                playerCamera.localRotation = Quaternion.Euler(cameraPitch, 0f, 0f);
            }
        }
    }

    private void MovePlayer()
    {
        Quaternion targetRotation = Quaternion.Euler(0f, playerYaw, 0f);
        rb.MoveRotation(targetRotation);

        Vector3 inputDirection = new Vector3(horizontalInput, 0f, verticalInput);
        inputDirection = Vector3.ClampMagnitude(inputDirection, 1f);

        Vector3 movementDirection = targetRotation * inputDirection;
        Vector3 targetVelocity = movementDirection * moveSpeed;
        Vector3 currentVelocity = rb.linearVelocity;

        float control = isGrounded ? 1f : airControl;
        float step = acceleration * control * Time.fixedDeltaTime;

        float newX = Mathf.MoveTowards(currentVelocity.x, targetVelocity.x, step);
        float newZ = Mathf.MoveTowards(currentVelocity.z, targetVelocity.z, step);

        rb.linearVelocity = new Vector3(newX, currentVelocity.y, newZ);
    }

    private void TryJump()
    {
        if (jumpBufferCounter <= 0f || coyoteCounter <= 0f) return;

        jumpBufferCounter = 0f;
        coyoteCounter = 0f;

        Vector3 velocity = rb.linearVelocity;
        velocity.y = 0f;
        rb.linearVelocity = velocity;

        rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        isGrounded = false;

        if (GameTimer.Instance != null)
        {
            GameTimer.Instance.PlayJumpSound();
        }
    }

    private void OnCollisionStay(Collision collision)
    {
        for (int i = 0; i < collision.contactCount; i++)
        {
            if (collision.GetContact(i).normal.y > 0.5f)
            {
                isGrounded = true;
                return;
            }
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        isGrounded = false;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "FinishLine" && GameTimer.Instance != null)
        {
            GameTimer.Instance.WinGame();
        }
    }
}
