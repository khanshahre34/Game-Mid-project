using UnityEngine;

public class MovingPlatform : MonoBehaviour
{
    [SerializeField] private float distance = 5f;
    [SerializeField] private float speed = 2f;
    [SerializeField] private Transform coin;

    private Vector3 platformStartPosition;
    private Vector3 coinStartPosition;

    private void Start()
    {
        platformStartPosition = transform.position;

        if (coin != null)
        {
            // Keep the coin separate so its shape is unchanged.
            coin.SetParent(null, true);
            coinStartPosition = coin.position;
        }
    }

    private void Update()
    {
        float offset =
            Mathf.PingPong(Time.time * speed, distance * 2f) - distance;

        Vector3 movement = Vector3.right * offset;

        transform.position = platformStartPosition + movement;

        if (coin != null)
        {
            coin.position = coinStartPosition + movement;
        }
    }
}