using UnityEngine;

public class RespawnPlayer : MonoBehaviour
{
    public Transform spawnPoint;

    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("DeathZone touched by: " + other.name);

        if (other.CompareTag("Player"))
        {
            Debug.Log("PLAYER FELL! Respawning...");

            Rigidbody rb = other.GetComponent<Rigidbody>();

            if (rb != null)
            {
                rb.linearVelocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
            }

            other.transform.position = spawnPoint.position;
        }
    }
}