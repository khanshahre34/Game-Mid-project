using UnityEngine;

public class Coin : MonoBehaviour
{
    public int value = 10;

    private bool collected;

    private void Update()
    {
        transform.Rotate(0f, 120f * Time.deltaTime, 0f, Space.World);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (collected || !other.CompareTag("Player")) return;

        collected = true;

        if (GameTimer.Instance != null)
        {
            GameTimer.Instance.CollectCoin(value);
        }

        Destroy(gameObject);
    }
}
