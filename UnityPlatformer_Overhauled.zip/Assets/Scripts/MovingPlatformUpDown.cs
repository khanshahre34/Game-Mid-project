using UnityEngine;

public class MovingPlatformUpDown : MonoBehaviour
{
    [SerializeField] private float height = 5f;
    [SerializeField] private float speed = 2f;
    [SerializeField] private Transform coin;

    private Vector3 platformStartPosition;
    private Vector3 coinStartPosition;

    private void Start()
    {
        platformStartPosition = transform.position;

        if (coin != null)
        {
            // Keep the coin's shape unchanged.
            coin.SetParent(null, true);
            coinStartPosition = coin.position;
        }
    }

    private void Update()
    {
        // Produces a value from 0 to height, never below 0.
        float upwardOffset = Mathf.PingPong(
            Time.time * speed,
            height
        );

        Vector3 movement = Vector3.up * upwardOffset;

        transform.position = platformStartPosition + movement;

        if (coin != null)
        {
            coin.position = coinStartPosition + movement;
        }
    }
}